DROP FUNCTION If EXISTS discount;
CREATE FUNCTION discount(composer_in VARCHAR(16), discount_in FLOAT) 
RETURNS INT
BEGIN
IF discount_in BETWEEN 0.05 AND 0.5 THEN
   UPDATE music SET price = price * (1.0 - discount_in) WHERE composer = composer_in;
   RETURN ROW_COUNT();
ELSE
   RETURN -1;   
END IF;
END;

          
