package coreservlets;

import java.sql.*;

/** Perform the following tests on a database:
 *  <OL>
 *  <LI>Create a JDBC connection to the database and report
 *      the product name and version.
 *  <LI>Create a simple "authors" table containing the
 *      ID, first name, and last name for the two authors
 *      of Core Servlets and JavaServer Pages, 2nd Edition.
 *  <LI>Query the "authors" table for all rows.
 *  <LI>Determine the JDBC version. Use with caution:
 *      the reported JDBC version does not mean that the
 *      driver has been certified.
 *  </OL>
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall and Larry Brown.
 *  May be freely used or adapted.
 */

public class TestDatabase {
  private String driver;
  private String url;
  private String username;
  private String password;

  public TestDatabase(String driver, String url,
                      String username, String password) {
    this.driver = driver;
    this.url = url;
    this.username = username;
    this.password = password;
  }

  /** Test the JDBC connection to the database and report the
   *  product name and product version.
   */

  public void testConnection() {
    System.out.println();
    System.out.println("Testing database connection ...\n");
    Connection connection = getConnection();
    if (connection == null) {
      System.out.println("Test failed.");
      return;
    }
    try {
      DatabaseMetaData dbMetaData = connection.getMetaData();
      String productName =
        dbMetaData.getDatabaseProductName();
      String productVersion =
        dbMetaData.getDatabaseProductVersion();
      String driverName = dbMetaData.getDriverName();
      String driverVersion = dbMetaData.getDriverVersion();
      System.out.println("Driver: " + driver);
      System.out.println("URL: " + url);
      System.out.println("Username: " + username);
      System.out.println("Password: " + password);
      System.out.println("Product name: " + productName);
      System.out.println("Product version: " + productVersion);
      System.out.println("Driver Name: " + driverName);
      System.out.println("Driver Version: " + driverVersion);
    } catch(SQLException sqle) {
      System.err.println("Error connecting: " + sqle);
    } finally {
      closeConnection(connection);
    }
    System.out.println();
  }


  /** Perform a nonrigorous test for the JDBC version.
   *  Initially, a last() operation is attempted for
   *  JDBC 2.0. Then, calls to getJDBCMajorVersion and
   *  getJDBCMinorVersion are attempted for JDBC 3.0.
   */

  public void checkJDBCVersion() {
    System.out.println();
    System.out.println("Checking JDBC version ...\n");
    Connection connection = getConnection();
    if (connection == null) {
      System.out.println("Check failed.");
      return;
    }
    int majorVersion = 1;
    int minorVersion = 0;
    try {
      Statement statement = connection.createStatement(
                              ResultSet.TYPE_SCROLL_INSENSITIVE,
                              ResultSet.CONCUR_READ_ONLY);
      String query = "SELECT * FROM authors";
      ResultSet resultSet = statement.executeQuery(query);
      resultSet.last(); // JDBC 2.0
      majorVersion = 2;
    } catch(SQLException sqle) {
      // Ignore - last() not supported
    }
    try {
      DatabaseMetaData dbMetaData = connection.getMetaData();
      majorVersion = dbMetaData.getJDBCMajorVersion(); // JDBC 3.0
      minorVersion = dbMetaData.getJDBCMinorVersion(); // JDBC 3.0
    } catch(Throwable throwable) {
      // Ignore - methods not supported
    } finally {
      closeConnection(connection);
    }
    System.out.println("JDBC Version: " +
                       majorVersion + "." + minorVersion);
  }



  public void DBInfo() {
  	DatabaseMetaData dbMetaData = null;
    System.out.println();
    System.out.println("Checking database names ...\n");
    Connection connection = getConnection();
    if (connection == null) {
      System.out.println("Check failed.");
      return;
    }
    try {
      dbMetaData = connection.getMetaData();
      ResultSet rs = dbMetaData.getCatalogs();
      showResults("Catalogs", rs);
      
      
      ResultSetMetaData rsmd = rs.getMetaData();
	  int columnCount = rsmd.getColumnCount();

      System.out.println("Tabeles in catalogs ...\n");
      
      
      //Go to the first result
      rs.first();
      //Before te first
      rs.previous();
      String types[] = { "TABLE" };

	  while(rs.next()) {
        for(int i=1; i <= columnCount; i++) {
        	//set the current catalog (database)
        	connection.setCatalog(rs.getString(1));
        	System.out.println("Catalog: " + rs.getString(1));
        	DatabaseMetaData dbMD = connection.getMetaData();
   	       	ResultSet tRS = dbMD.getTables(null,null,"",types); 
   	       	while(tRS.next())
			     System.out.println("   Table: " + tRS.getString("TABLE_NAME"));
           }
         } 
      
      if(dbMetaData.allProceduresAreCallable())
      	System.out.println("User can call procedures");
      else 	System.out.println("User can NOT call procedures");
     	 	
      		
     } catch(Throwable throwable) {
      // Ignore - methods not supported
      System.out.println(throwable);
   }finally {
      closeConnection(connection);
    }
    
  }



  /** Obtain a new connection to the database or return
   *  null on failure.
   */

  public Connection getConnection() {
    try {
      Class.forName(driver);
      Connection connection =
        DriverManager.getConnection(url, username,
                                    password);
      return(connection);
    } catch(ClassNotFoundException cnfe) {
      System.err.println("Error loading driver: " + cnfe);
      return(null);
    } catch(SQLException sqle) {
      System.err.println("Error connecting: " + sqle);
      return(null);
    }
  }

  /** Close the database connection. */

  private void closeConnection(Connection connection) {
    try {
      connection.close();
    } catch(SQLException sqle) {
      System.err.println("Error closing connection: " + sqle);
      connection = null;
    }
  }

  public static void main(String[] args) {
    if (args.length < 5) {
      printUsage();
      return;
    }
    String vendor = args[4];
    // Change to DriverUtilities2.loadDrivers() to
    // load the drivers from an XML file.
    DriverUtilities.loadDrivers();
    if (!DriverUtilities.isValidVendor(vendor)) {
      printUsage();
      return;
    }
    String driver = DriverUtilities.getDriver(vendor);
    String host = args[0];
    String dbName = args[1];
    
    
    //This URL points at the server not at the particular database on tsi server
    String url =
      DriverUtilities.makeURL(host, "" , vendor);
    String username = args[2];
    String password = args[3];

    TestDatabase database =
      new TestDatabase(driver, url, username, password);
    database.testConnection();
    database.checkJDBCVersion();
    database.DBInfo();
  }
  private static void printUsage() {
    System.out.println("Usage: TestDatabase host dbName " +
                       "username password vendor.");
  }
    
  private  void showResults(String title, ResultSet results) throws SQLException {
	System.out.println("--------"+title+"--------");
	ResultSetMetaData rsmd = results.getMetaData();
	int columnCount = rsmd.getColumnCount();
	
	while(results.next()) {
	        // Step across the row, retrieving the data in each
	        // column cell as a String.
	        for(int i=1; i <= columnCount; i++) {
	          System.out.println(" " + results.getString(i));
	        }
	        System.out.println();
	      } 
	System.out.println("-------------------------------");
    }
    
}
 