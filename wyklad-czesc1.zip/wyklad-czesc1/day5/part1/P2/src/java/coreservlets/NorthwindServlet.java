package coreservlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

/** A simple servlet that connects to a database and
 *  presents the results from the query in an HTML
 *  table. The driver, URL, username, password,
 *  and query are taken from form input parameters.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall and Larry Brown.
 *  May be freely used or adapted.
 */

public class NorthwindServlet extends HttpServlet {
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String docType =
      "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
      "Transitional//EN\"\n";
    String title = "Northwind Results";
    out.print(docType +
              "<HTML>\n" +
              "<HEAD><TITLE>" + title + "</TITLE></HEAD>\n" +
              "<BODY BGCOLOR=\"#FDF5E6\"><CENTER>\n" +
              "<H1>Database Results</H1>\n");
    String driver = request.getParameter("driver");
    String url = request.getParameter("url");
    String username = request.getParameter("username");
    String password = request.getParameter("password");
    String query = request.getParameter("query");
    showTable(driver, url, username, password, query, out);
    out.println("</CENTER></BODY></HTML>");
  }

  public void showTable(String driver, String url,
                        String username, String password,
                        String query, PrintWriter out) {
    try {
      // Load database driver if it's not already loaded.
      Class.forName(driver);
      // Establish network connection to database.
      Connection connection =
        DriverManager.getConnection(url, username, password);
      // Look up info about the database as a whole.
      DatabaseMetaData dbMetaData = connection.getMetaData();
      out.println("<UL>");
      String productName =
        dbMetaData.getDatabaseProductName();
      String productVersion =
        dbMetaData.getDatabaseProductVersion();
      out.println("  <LI><B>Database:</B> " + productName +
                  "  <LI><B>Version:</B> " + productVersion +
                  "</UL>");
      Statement statement = connection.createStatement();
      // Send query to database and store results.
      ResultSet resultSet = statement.executeQuery(query);
      // Print results.
      out.println("<TABLE BORDER=1>");
      ResultSetMetaData resultSetMetaData =
        resultSet.getMetaData();
      int columnCount = resultSetMetaData.getColumnCount();
      out.println("<TR>");
      // Column index starts at 1 (a la SQL), not 0 (a la Java).
      for(int i=1; i <= columnCount; i++) {
        out.print("<TH>" + resultSetMetaData.getColumnName(i));
      }
      out.println();
      // Step through each row in the result set.
      while(resultSet.next()) {
        out.println("<TR>");
        // Step across the row, retrieving the data in each
        // column cell as a String.
        for(int i=1; i <= columnCount; i++) {
          out.print("<TD>" + resultSet.getString(i));
        }
        out.println();
      }
      out.println("</TABLE>");
      connection.close();
    } catch(ClassNotFoundException cnfe) {
      System.err.println("Error loading driver: " + cnfe);
    } catch(SQLException sqle) {
      System.err.println("Error connecting: " + sqle);
    } catch(Exception ex) {
      System.err.println("Error with input: " + ex);
    }
  }

  private static void showResults(ResultSet results)
      throws SQLException {
    while(results.next()) {
      System.out.print(results.getString(1) + " ");
    }
    System.out.println();
  }

  private static void printUsage() {
    System.out.println("Usage: PreparedStatements host " +
                       "dbName username password " +
                       "vendor [print].");
  }
}            