package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/** Servlet that displays a form for order Items.
 *  Used to demonstrate basic
 *  session tracking without cookie. Updated to Java 5.
 *  <P>
 *  Taken/modified from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall; may be freely used or adapted.
 */

@SuppressWarnings("unchecked")

public class OrderForm extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {

    HttpSession session = request.getSession();
//You must create a session first. Try to run this servlet after deleting the previous line.

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String title = "Order Form";
    String docType =
      "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
      "Transitional//EN\">\n";
    out.println(docType +
                "<HTML>\n" +
                "<HEAD><TITLE>" + title + "</TITLE></HEAD>\n" +
                "<BODY BGCOLOR=\"#FDF5E6\">\n" +
		"<CENTER>" +
		"<H1>Order Form</H1>" +
		"<FORM ACTION="+ response.encodeURL("ShowItems") +">" +
		  "New Item to Order:  " +
		  "<INPUT TYPE=\"TEXT\" NAME=\"newItem\" VALUE=\"Yacht\"><P>" +
		  "<INPUT TYPE=\"SUBMIT\" VALUE=\"Order and Show All Purchases\">" +
		"</FORM>" +
		"</CENTER></BODY></HTML>");
  }
}
