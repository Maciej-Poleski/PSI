// Example from http://www.alemoi.com/dev/httpaccess/


package coreservlets;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.commons.codec.binary.Base64;


/**
* Login
*/
public class Login extends HttpServlet
{
   public void doGet(
         HttpServletRequest request,
         HttpServletResponse response)
      throws ServletException, IOException
   {
      String userID = null;
      String password = null;

      // Assume not valid until proven otherwise

      boolean valid = false;

      // Get the Authorization header, if one was supplied

      String authHeader = request.getHeader("Authorization");
      if (authHeader != null) {
         StringTokenizer st = new StringTokenizer(authHeader);
         if (st.hasMoreTokens()) {
            String basic = st.nextToken();

            // We only handle HTTP Basic authentication

            if (basic.equalsIgnoreCase("Basic")) {
               String credentials = st.nextToken();

               // This example uses sun.misc.* classes.
               // You will need to provide your own
               // if you are not comfortable with that.

               String userPass =
                  new String(Base64.decodeBase64(credentials.getBytes()));

               // The decoded string is in the form
               // "userID:password".

               int p = userPass.indexOf(":");
               if (p != -1) {
                  userID = userPass.substring(0, p);
                  password = userPass.substring(p+1);

                  // Validate user ID and password
                  // and set valid true true if valid.
                  // In this example, we simply check
                  // that neither field is blank

                  if ((!userID.trim().equals("")) &&
                      (!password.trim().equals(""))) {
                     valid = true;
                  }
               }
            }
         }
      }

      // If the user was not validated, fail with a
      // 401 status code (UNAUTHORIZED) and
      // pass back a WWW-Authenticate header for
      // this servlet.
      //
      // Note that this is the normal situation the
      // first time you access the page.  The client
      // web browser will prompt for userID and password
      // and cache them so that it doesn't have to
      // prompt you again.

      if (!valid) {
         String s = "Basic realm=\"Login Test Servlet Users\"";
         response.setHeader("WWW-Authenticate", s);
         response.setStatus(401);
      }

      // Otherwise, proceed

      else {
         response.setContentType("text/html");
         PrintWriter out = response.getWriter();
         out.println("<H3>Hello, " + userID + "</H3>");
         out.println("You are authorized to proceed.");
      }

   }
}
